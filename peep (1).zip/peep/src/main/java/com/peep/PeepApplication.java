package com.peep;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PeepApplication {

	public static void main(String[] args) {
		SpringApplication.run(PeepApplication.class, args);
	}

}
